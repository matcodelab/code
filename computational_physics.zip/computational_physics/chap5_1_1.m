%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Jacobi method to solve Laplace equation
% based on 'Computational Physics' book by N Giordano and H Nakanishi
% Section 5.1
% by Kevin Berwick
%
% Load array into V
[V] =Initialise_prism;
% run update routine and estimate convergence
[V_new, delta_V_new]=Update_prism(V);
%Initialise loop counter
loops=0;
% While we have not met the convergence criterion and the number of loops
% is <10 so that we give the  relaxation
% algorithm time to converge
% while (delta_V_new > & loops < 30);
 while (delta_V_new>4e-5 | loops < 20);
 loops=loops+1;
 [V_new, delta_V_new]=Update_prism(V_new);
 % draw the surface using the mesh function
% mesh (V_new,'FaceColor','interp','EdgeColor','none','FaceLighting','phong');
 mesh (V_new,'FaceColor','interp');
 title('Potential Surface');
 axis([0 20 0 20 0 1]);
 drawnow;
 % insert a pause here so we see the evolution of the potential
 % surface
 pause(0.5);
 end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Jacobi method to solve Laplace equation
% based on 'Computational Physics' book by N Giordano and H Nakanishi
% Section 5.1
% by Kevin Berwick
%
% This function creates the intial voltage array V
function[V] =Initialise_prism;
 
% clear variables
clear;
V = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 1 1 1 1 1 1 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 1 1 1 1 1 1 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 1 1 1 1 1 1 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 1 1 1 1 1 1 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 1 1 1 1 1 1 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 1 1 1 1 1 1 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 ];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ V_new, delta_V_new] = Update_prism(V);
% This function takes a matrix V and applies Eq 5.10 to it. Only the values
% inside the boundaries are  changed. It returns the  processed matrix to
% the calling function, together with the value of delta_V, the total
% accumulated amount by which the elements 
% of the matrix have changed
row_size = size(V,1);
column_size=size(V,2);
% preallocate memeory for speed
V_new=V;
delta_V_new=0;
% Move along the matrix, element by element computing Eq 5.10, ignoring
% boundaries
 for j =2:column_size-1;
 for i=2:row_size -1;

 % Do not update V in metal bar
 if V(i,j) ~=1;
 % If the value of V is not =1, calculate V_new and
 % delta_V_new to test for convergence
 V_new(i,j) = (V(i-1,j)+V(i+1,j)+V(i,j-1)+V(i,j+1))/4;
 delta_V_new=delta_V_new+abs(V_new(i,j)-V(i,j))
 else
 % otherwise, leave value unchanged
 V_new(i,j)=V(i,j);
 end;
 end;
 end; 
end