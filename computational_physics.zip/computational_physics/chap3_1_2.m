%
% Simple harmonic motion - comparison of Euler, Euler Cromer
% and 2nd order Runge Kutta and built in MATLAB Runge Kutta
% function ODE45to solve ODEs.
% by Kevin Berwick,
% based on 'Computational Physics' book by N Giordano and H Nakanishi,
% section 3.1
% Equation is d2y/dt2 = -y
% Calculate the numerical solution using Euler method in red
[time,y] = SHM_Euler (10);
subplot(2,2,1);
plot(time,y,'r' );
axis([0 100 -100 100]);
xlabel('Time');
ylabel('Displacement');
legend ('Euler method');
% Calculate the numerical solution using Euler Cromer method in blue
[time,y] = SHM_Euler_Cromer (10);
subplot(2,2,2);
plot(time,y,'b' );
axis([0 100 -20 20]);
xlabel('Time');
ylabel('Displacement');
legend ('Euler Cromer method');
% Calculate the numerical solution using Second order Runge-Kutta method in green
[time,y] = SHM_Runge_Kutta (10);
subplot(2,2,3);
plot(time,y,'g' );
axis([0 100 -20 20]);
xlabel('Time');
ylabel('Displacement');
legend ('Runge-Kutta method');
% Use the built in MATLAB ODE45 solver to solve the ODE
% The function describing the SHM equations is called my_shm
% The time values range from 0 to 100
% The initial velocity is 0, the initial displacement is 10
[t,y]=ode23(@SHM_ODE45_function,[0,100],[0,10]);
% We need to plot the second column of the y matrix, containing the
% displacement against time in black
subplot(2,2,4);
plot(t,y(:,2),'k');
axis([0 100 -20 20]);
xlabel('Time');
ylabel('Displacement');
legend ('ODE45 Solver');

%
% Simple harmonic motion - Euler method
% by Kevin Berwick,
% based on 'Computational Physics' book by N Giordano and H Nakanishi,
% section 3.1
% Equation is d2y/dt2 = -y
function [time,y] = SHM_Euler (initial_displacement);
npoints = 2500; %Discretize time into 250 intervals
dt = 0.04; % time step in seconds
v = zeros(npoints,1); % initializes v, a vector of dimension npoints X 1,to being all zeros
y = zeros(npoints,1); % initializes y, a vector of dimension npoints X 1,to being all zeros
time = zeros(npoints,1); % this initializes the vector time to being all zeros
y(1)=initial_displacement; % need some initial displacement
% Euler solution
for step = 1:npoints-1 % loop over the timesteps
v(step+1) = v(step) - y(step)*dt;
y(step+1) = y(step)+v(step)*dt;
time(step+1) = time(step) + dt;
end
end


%
% Simple harmonic motion - Euler Cromer method
% by Kevin Berwick,
% based on 'Computational Physics' book by N Giordano and H Nakanishi,
% section 3.1
% Equation is d2y/dt2 = -y
function [time,y] = SHM_Euler_Cromer (initial_displacement);
npoints = 2500; %Discretize time into 250 intervals
dt = 0.04; % time step in seconds
v = zeros(npoints,1); % initializes v, a vector of dimension npoints X 1,to being all zeros
y = zeros(npoints,1); % initializes y, a vector of dimension npoints X 1,to being all zeros
time = zeros(npoints,1); % this initializes the vector time to being all zeros
y(1)=initial_displacement; % need some initial displacement
% Euler Cromer solution
for step = 1:npoints-1 % loop over the timesteps
v(step+1) = v(step) - y(step)*dt;
y(step+1) = y(step)+v(step+1)*dt;
time(step+1) = time(step) + dt;
end
end
%
% Simple harmonic motion - Second order Runge Kutta method
% by Kevin Berwick,
% based on 'Computational Physics' book by N Giordano and H Nakanishi,
% section 3.1

% Equation is d2y/dt2 = -y
function [time,y] = SHM_Runge_Kutta(initial_displacement);
% 2nd order Runge Kutta solution
npoints = 2500; %Discretize time into 250 intervals
dt = 0.04; % time step in seconds
v = zeros(npoints,1); % initializes v, a vector of dimension npoints X 1,to being all zeros
y = zeros(npoints,1); % initializes y, a vector of dimension npoints X 1,to being all zeros
time = zeros(npoints,1); % this initializes the vector time to being all zeros
y(1)=initial_displacement; % need some initial displacement
v = zeros(npoints,1); % initializes v, a vector of dimension npoints X 1,to being all zeros
y = zeros(npoints,1); % initializes y, a vector of dimension npoints X 1,to being all zeros
v_dash = zeros(npoints,1); % initializes y, a vector of dimension npoints X 1,to being all zeros
y_dash = zeros(npoints,1); % initializes y, a vector of dimension npoints X 1,to being all zeros
time = zeros(npoints,1); % this initializes the vector time to being all zeros
y(1)=10; % need some initial displacement
for step = 1:npoints-1 % loop over the timesteps
 v_dash=v(step)-0.5*y(step)*dt;
 y_dash=y(step)+0.5*v(step)*dt;

 v(step+1) = v(step)-y_dash*dt;
 y(step+1) = y(step)+v_dash*dt;
 time(step+1) = time(step)+dt;
end
end

%
% Simple harmonic motion - Built in MATLAB ODE45 method
% by Kevin Berwick,
% based on 'Computational Physics' book by N Giordano and H Nakanishi,
% section 3.1
% Equation is d2y/dt2 = -y
function dy = SHM_ODE45_function(t,y)
% y is the state vector
y1 = y(1); % y1 is displacement
v = y(2); % y2 is velocity
% write down the state equations
dy1=v;
dy2=-y1;
% collect the equations into a column vector, velocity in column 1,
% displacement in column 2
dy = [dy1;dy2];
end